#Bruce Ward
#Dominon card set search engine
#July 2021

import csv
print ("Dominion Card Set Search Engine")
#Ask user for card they wish to search for
cardName = input("What card do you want to search for? Or enter 1 to view a menu of card options. ")

#Loads Dominion card menu and card set data file
menufile = 'dominionCardMenu.csv'
filename = 'dominionCardSets.csv'

#If user chooses to see menu, this reads through menu and prints it out, and then asks for user's chosen card.
if cardName == '1':
    with open (menufile) as f:
        reader = csv.reader(f)
        header_row = next(reader)
        
        for row in reader:
            print (row[0])
        cardName = input("What card to you want to search for? ")

#Create a flag variable to check for invalid input
flag = 0

#Goes through data file line by line
with open (filename) as f:
    reader = csv.reader(f)

    #Reads through header row
    header_row = next(reader)

    #Reads next row in data file
    for row in reader:
        startCounter = 3
        endCounter = 13

        #Goes through the ten cards for this row, checking for matching results
        for value in range(startCounter, endCounter):
            checkCard = row[value]

            #If the name of the card entered is found, then print card set
            if (cardName.title() == checkCard.title()):
                flag = 1

                #Formating data to print nicely
                print (row[0])
                print ("Expansions:    " + row[1] + " " + row[2])
                print ("Kingdom Cards: ", end = '')
                for value2 in range(startCounter, endCounter):                
                    if (value2 != endCounter - 1):
                        print (row[value2]+ ", ", end = '')
                    else:
                        print (row[value2])
                print ("Additional Items: " + row[13])
                print ("\n")
                
#No matching sets found, printing error message  
    if flag == 0:
        print ("Sorry, no sets with that card were found.")
        
                

            
        

        
        

